function Footer() {
    try {
        return (
            <footer data-name="footer" className="bg-black py-12">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div data-name="footer-about" className="space-y-4">
                            <h3 className="text-xl font-bold">Pankaj Naikwade</h3>
                            <p className="text-gray-400">Professional Videographer & Editor specializing in cinematography and visual storytelling.</p>
                        </div>
                        
                        <div data-name="footer-contact" className="space-y-4">
                            <h3 className="text-xl font-bold">Contact</h3>
                            <div className="space-y-2">
                                <a href="tel:+918459733272" className="flex items-center text-gray-400 hover:text-white transition-colors">
                                    <i className="fas fa-phone mr-2"></i>
                                    <span>+91 8459733272</span>
                                </a>
                                <a href="mailto:pankajnaik1496@gmail.com" className="flex items-center text-gray-400 hover:text-white transition-colors">
                                    <i className="fas fa-envelope mr-2"></i>
                                    <span>pankajnaik1496@gmail.com</span>
                                </a>
                                <div className="flex space-x-4 pt-4">
                                    <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                                        <i className="fab fa-instagram text-xl"></i>
                                    </a>
                                    <a href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                                        <i className="fab fa-youtube text-xl"></i>
                                    </a>
                                    <a href="https://linkedin.com/in/pankaj-naikwade" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                                        <i className="fab fa-linkedin text-xl"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div data-name="footer-copyright" className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
                        <p>© {new Date().getFullYear()} Pankaj Naikwade. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        );
    } catch (error) {
        console.error('Footer component error:', error);
        reportError(error);
        return null;
    }
}
